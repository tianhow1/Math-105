function [b,F] = Divided_difference_Hermite(x,y,dy)
n = numel(x);
F = zeros(2*n,2*n);
F(1:2:end,1) = y; F(2:2:end,1) = y;  F(2:2:end,2) = dy;
X = zeros(2*n,1); X(1:2:end) = x;  X(2:2:end) = x;

...
    
...

b = diag(F);

end

